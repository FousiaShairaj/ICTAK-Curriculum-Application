package org.ict.constants;

public class AutomationConstants 
{
	public static final String CREATEACCOUNT ="User Login";
}

