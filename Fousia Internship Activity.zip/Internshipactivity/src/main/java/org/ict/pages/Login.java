package org.ict.pages;

import org.ict.base.Baseclass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login extends Baseclass
{
	public Login(WebDriver driver) 
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//a[@href=\"/login\" and @class=\"nav-item nav-link btn btn-primary px-4 d-inline text-light p-1 m-1\"]")
	WebElement login;
	
	@FindBy(xpath="//input[@aria-describedby=\"emailHelp\"]")
	WebElement email;
	
	@FindBy(xpath="//input[@id=\"exampleInputPassword1\" and @placeholder=\"Password\"]")
	WebElement password;
	
	@FindBy(xpath="//button[@type=\"submit\"]")
	WebElement submit;
	
	public void loginclick()
	{
		login.click();
	}
	public void emailfield(String emailfield) 
	{
		email.sendKeys(emailfield);
	}
	public void passwordfield(String passwordfield)
	{
		password.sendKeys(passwordfield);
	}
	public void submitbuttonclick()
	{
		submit.click();
	}
}
