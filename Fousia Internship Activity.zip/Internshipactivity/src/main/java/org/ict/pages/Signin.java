package org.ict.pages;

import java.io.IOException;

import org.ict.base.Baseclass;
import org.ict.excelutility.Excelfile;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Signin extends Baseclass
{
	public Signin(WebDriver driver) 
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//a[@href=\"/login\" and @class=\"nav-item nav-link btn btn-primary px-4 d-inline text-light p-1 m-1\"]")
	WebElement login;

	@FindBy(xpath="//a[@href=\"/signup\" and @class=\"create-account\"]")
	WebElement createaccount;
	
	@FindBy(xpath="//input[@type=\"text\" and @class=\"form-control ng-pristine ng-invalid is-invalid ng-touched\"]")
	WebElement Name;
	
	@FindBy(xpath="//input[@name=\"Email\" and @class=\"form-control ng-pristine ng-invalid ng-touched\"]")
	WebElement Email;
	
	@FindBy(xpath="//input[@type=\"text\" and @name=\"Contact\"]")
	WebElement Phonenumber;
	
	@FindBy(xpath="//input[@type=\"password\" and @name=\"Password\"]")
	WebElement Password;
	
	@FindBy(xpath="//input[@type=\"password\" and @name=\"ConfirmPassword\"]")
	WebElement Repassword;
	
	@FindBy(xpath="//button[@type=\"submit\" and @class=\"btn btn-primary\"]")
	WebElement Signinbutton;
	
		
	@FindBy(xpath="//h2[@class=\"text-primary text-center\"]")
	WebElement Createpagetitle;
	
	public void loginclick()
	{
		login.click();
	}
	public void createaccountlink()

	{
		createaccount.click();

	}
	
	public void setname(String emailfield) 

	{

		Name.sendKeys(emailfield);

	}
	
	public void setemail(String emailfield) 

	{

		Email.sendKeys(emailfield);

	}
	
	public void setnumber(String emailfield) 

	{

		Phonenumber.sendKeys(emailfield);

	}
	
	public void setpassword(String emailfield) 

	{

		Password.sendKeys(emailfield);

	}
	public void setconform(String emailfield) 

	{

		Repassword.sendKeys(emailfield);

	}
	public void Signinclick()

	{

		Signinbutton.click();

	}
	
	public String expectedsignin() throws Exception

	{

	 return Excelfile.getData(0, 3);

	}

	public String actualsignin() throws IOException

	{

		return Signinbutton.getText();

	}
	
	public String getTitlecreate()
	{
	String StrTitlecreate = Createpagetitle.getText();
	return StrTitlecreate;
	}
}
