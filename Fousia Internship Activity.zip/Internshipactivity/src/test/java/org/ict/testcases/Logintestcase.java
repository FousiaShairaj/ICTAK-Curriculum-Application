package org.ict.testcases;

import java.io.IOException;

import org.ict.base.Baseclass;
import org.ict.excelutility.Excelfile;
import org.ict.pages.Login;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
public class Logintestcase extends Baseclass
{
 Login loginkey;
 @BeforeMethod
		public void init() 
		{
			loginkey= new Login(driver);
		}
 	@Test(priority=1)
	public void Loginpage()
	{
		loginkey.loginclick();	
	}
 	
 	
 	@Test(priority=2)
	public void Enteremail() throws IOException
	{	
		String email = Excelfile.getData(0, 0);
		loginkey.emailfield(email);
	}
 	@Test(priority=3)
	public void Enterpassword() throws IOException
	{
	String password = Excelfile.getData(0, 1);
	loginkey.passwordfield(password);
	}
 	@Test(priority=4)
	public void Submitclick()
	{
		loginkey.submitbuttonclick();
	}
 	
	}