package org.ict.testcases;

import org.ict.base.Baseclass;
import org.ict.constants.AutomationConstants;
import org.ict.excelutility.Excelfile;
import org.ict.pages.Signin;
import org.testng.Assert;
import org.testng.annotations.Test;



public class Signintestcase extends Baseclass
{
	Signin signinclick;
	
	@Test (priority = 1)
	public void Loginpageclick()
	{
		signinclick = new Signin(driver);
		
		signinclick.loginclick();
		
	}
	
	@Test (priority = 2)
	public void Clickcreateaccount() throws Throwable
	{

	signinclick.createaccountlink();
	
	String expTitle = signinclick.getTitlecreate();

	String actTitle = AutomationConstants.CREATEACCOUNT;

	System.out.println(actTitle+ "Title:" +expTitle);

	Assert.assertEquals(actTitle, expTitle);

	}
	
	@Test(priority =3)

	public void signinform() throws Exception
	{
		
		String Name = Excelfile.getData(0, 2);

		String Email = Excelfile.getData(0, 0);

		String Phonenumber = Excelfile.getData(1, 2);	

		String Password = Excelfile.getData(0, 1);
		
		String Repassword = Excelfile.getData(0, 1);
		

		signinclick.setname(Name);

		signinclick.setemail(Email);

		signinclick.setnumber(Phonenumber);

		signinclick.setpassword(Password);
		
		signinclick.setconform(Repassword);

		signinclick.Signinclick();

		String expectedResult = signinclick.expectedsignin();

		String actualResult = signinclick.actualsignin();

		Assert.assertEquals(actualResult, expectedResult);

	}

}
